﻿using CMSShoppingCart.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMSShoppingCart.Infrastructure
{
    public class CategoriesViewComponent : ViewComponent
    {
        // inject the database context through constructor 
        private readonly CMSShoppingCartContext context;

        public CategoriesViewComponent(CMSShoppingCartContext context)
        {
            this.context = context;
        }

        // show pages 
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var categories = await GetCategoriesAsync();
            return View(categories);
        }

        private Task<List<Category>> GetCategoriesAsync()
        {
            return context.Categories.OrderBy(x => x.Sorting).ToListAsync();
        }
    }
}
