﻿ using CMSShoppingCart.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMSShoppingCart.Infrastructure
{
    public class MainMenuViewComponent : ViewComponent
    {
        // inject the database context through constructor 
        private readonly CMSShoppingCartContext context;

        public MainMenuViewComponent(CMSShoppingCartContext context)
        {
            this.context = context;
        }

        // show pages 
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var pages = await GetPagesAsync();
            return View(pages);
        }

        private Task<List<Page>> GetPagesAsync()
        {
            return context.Pages.OrderBy(x => x.Sorting).ToListAsync();
        }
    }
}
