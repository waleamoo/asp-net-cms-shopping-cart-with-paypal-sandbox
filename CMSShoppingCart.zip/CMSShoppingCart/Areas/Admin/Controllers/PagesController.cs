﻿using CMSShoppingCart.Infrastructure;
using CMSShoppingCart.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMSShoppingCart.Areas.Admin.Controllers
{
    [Authorize(Roles = "admin,editor")]
    [Area("Admin")]
    public class PagesController : Controller
    {
        // inject the database context through constructor 
        private readonly CMSShoppingCartContext context;

        public PagesController(CMSShoppingCartContext context)
        {
            this.context = context;
        }

        // IActionResult result returns any basically: view, redirect and so on...
        // IRedirectResult

        // GET
        public async Task<IActionResult> Index() 
        {
            IQueryable<Page> pages = from p in context.Pages orderby p.Sorting select p;
            List<Page> pagesList = await pages.ToListAsync();
            return View(pagesList);
        }

        // Ctrl + D to Copy
        // GET /admin/pages/details/5
        public async Task<IActionResult> Details(int id) 
        {
            Page page = await context.Pages.FirstOrDefaultAsync(x => x.Id == id);
            if (page == null)
            {
                return NotFound();
            }
            else
            {
                return View(page);
            }
        }

        // GET /admin/pages/create 
        public IActionResult Create() => View(); // return View();

        // POST /admin/pages/create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Page page)
        {
            // get the form data: Model Binding 
            // How Model Binding Gets Data: Parameter, Query String and via Route Parameters
            // validate the form 
            if (ModelState.IsValid)
            {
                page.Slug = page.Title.ToLower().Replace(" ", "-");
                page.Sorting = 100;
                // check if slug exists 
                var slug = await context.Pages.FirstOrDefaultAsync(x => x.Slug == page.Slug);
                if (slug != null)
                {
                    ModelState.AddModelError("", "The page already exists");
                    return View(page);
                }
                context.Add(page);
                await context.SaveChangesAsync();

                TempData["Success"] = "The page has been added";

                return RedirectToAction("Index");
            }

            TempData["Error"] = "Problem occured creating page.";

            return View(page);
        }

        public async Task<IActionResult> Edit(int id)
        {
            Page page = await context.Pages.FindAsync(id);
            if (page == null)
            {
                return NotFound();
            }
            return View(page);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Page page)
        {
            if (ModelState.IsValid)
            {
                // check if the page is home 
                page.Slug = page.Id == 1 ? "home" : page.Title.ToLower().Replace(" ", "-");
                // check if slug exists for any other page, but not this particular page 
                var slug = await context.Pages.Where(x => x.Id != page.Id).FirstOrDefaultAsync(x => x.Slug == page.Slug);
                if (slug != null)
                {
                    ModelState.AddModelError("", "The page already exists");
                    return View(page);
                }
                context.Update(page);
                await context.SaveChangesAsync();

                TempData["Success"] = "The page has been edited";

                return RedirectToAction("Edit", new { Id = page.Id });
            }

            TempData["Error"] = "Problem occured editing page.";

            return View(page);
        }

        public async Task<IActionResult> Delete(int id)
        {
            Page page = await context.Pages.FindAsync(id);
            if (page == null)
            {
                TempData["Error"] = "The page does not exist";
                return NotFound();
            }

            context.Pages.Remove(page);
            await context.SaveChangesAsync();
            TempData["Success"] = "The page has been deleted";

            return RedirectToAction("Index");
        }


        [HttpPost]
        public async Task<IActionResult> Reorder (int[] id)
        {
            int count = 1;
            foreach (var pageId in id)
            {
                Page page = await context.Pages.FindAsync(pageId);
                page.Sorting = count;
                context.Update(page);
                await context.SaveChangesAsync();
                count++;
            }
            return Ok();
        }


    }
}
