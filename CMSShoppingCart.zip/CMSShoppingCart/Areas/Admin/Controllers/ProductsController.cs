﻿using CMSShoppingCart.Infrastructure;
using CMSShoppingCart.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CMSShoppingCart.Areas.Admin.Controllers
{
    [Authorize(Roles = "admin")]
    [Area("Admin")]
    public class ProductsController : Controller
    {
        // inject the database context through constructor 
        private readonly CMSShoppingCartContext context;

        private readonly IWebHostEnvironment webHostingEnvironment;

        public ProductsController(CMSShoppingCartContext context, IWebHostEnvironment webHostingEnvironment)
        {
            this.context = context;
            this.webHostingEnvironment = webHostingEnvironment; 
        }

        public async Task<IActionResult> Index(int p = 1)
        {
            // use github codehaks.pagination github.com/codehaks/Codehaks.Pagination copy the PaginationTagHelper.cs
            // <Pagination page-count="@Model.TotalPages" page-target="/index" page-number="@Model.PageNumber" page-range="10"></Pagination>
            // @addTagHelper *, Codehaks.Pagination
            int pageSize = 6;
            var products = context.Products.OrderByDescending(x => x.Id)
                .Include(x => x.category)
                .Skip((p - 1) * pageSize)
                .Take(pageSize);
            ViewBag.PageNumber = p;
            ViewBag.PageRange = pageSize;
            ViewBag.TotalPages = (int)Math.Ceiling((decimal)context.Products.Count() / pageSize);
            return View(await products.ToListAsync());
            //return View(await context.Products.OrderBy(x => x.Id).Include(x => x.category).ToListAsync());
        }

        public IActionResult Create()
        {
            ViewBag.categoryId = new SelectList(context.Categories.OrderBy(x => x.Sorting), "Id", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Product product)
        {
            ViewBag.categoryId = new SelectList(context.Categories.OrderBy(x => x.Sorting), "Id", "Name");


            if (ModelState.IsValid)
            {
                product.Slug = product.Name.ToLower().Replace(" ", "-");
                // check if slug exists 
                var slug = await context.Products.FirstOrDefaultAsync(x => x.Slug == product.Slug);
                if (slug != null)
                {
                    ModelState.AddModelError("", "The product already exists");
                    return View(product);
                }

                // upload the image 
                string imageName = "noimage.jpg"; // default image if no image is uploaded 
                if (product.ImageUpload != null)
                {
                    string uploadDir = Path.Combine(webHostingEnvironment.WebRootPath, "media/products");
                    imageName = Guid.NewGuid().ToString() + "_" + product.ImageUpload.FileName;
                    string filePath = Path.Combine(uploadDir, imageName);
                    FileStream fs = new FileStream(filePath, FileMode.Create);
                    await product.ImageUpload.CopyToAsync(fs);
                    fs.Close();
                }
                product.Image = imageName;
                context.Add(product);
                await context.SaveChangesAsync();

                TempData["Success"] = "The product has been added";

                return RedirectToAction("Index");
            }

            TempData["Error"] = "Problem occured creating product.";

            return View(product);
        }
        
        public async Task<IActionResult> Details(int id)
        {
            Product product = await context.Products.Include(x => x.category).FirstOrDefaultAsync(x => x.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            else
            {
                return View(product);
            }
        }

        public async Task<IActionResult> Edit(int id)
        {
            Product product = await context.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            // pass the category to the edit page 
            ViewBag.categoryId = new SelectList(context.Categories.OrderBy(x => x.Sorting), "Id", "Name", product.CategoryId);

            return View(product);
        }

        // POST /admin/products/edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            ViewBag.categoryId = new SelectList(context.Categories.OrderBy(x => x.Sorting), "Id", "Name", product.CategoryId);

            if (ModelState.IsValid)
            {
                product.Slug = product.Name.ToLower().Replace(" ", "-");
                // check if slug exists 
                var slug = await context.Products.Where(x => x.Id != id).FirstOrDefaultAsync(x => x.Slug == product.Slug);
                if (slug != null)
                {
                    ModelState.AddModelError("", "The product already exists");
                    return View(product);
                }

                // upload the image 
                if (product.ImageUpload != null)
                {
                    string uploadDir = Path.Combine(webHostingEnvironment.WebRootPath, "media/products");
                    if (!string.Equals(product.Image, "noimage.jpg"))
                    {
                        string oldImagePath = Path.Combine(uploadDir, product.Image);
                        if (System.IO.File.Exists(oldImagePath))
                        {
                            System.IO.File.Delete(oldImagePath);
                        }
                    }
                    string imageName = Guid.NewGuid().ToString() + "_" + product.ImageUpload.FileName;
                    string filePath = Path.Combine(uploadDir, imageName);
                    FileStream fs = new FileStream(filePath, FileMode.Create);
                    await product.ImageUpload.CopyToAsync(fs);
                    fs.Close();
                    product.Image = imageName;

                }
                context.Update(product);
                await context.SaveChangesAsync();

                TempData["Success"] = "The product has been edited";

                return RedirectToAction("Index");
            }

            TempData["Error"] = "Problem occured editing product.";

            return View(product);
        }

        // GET /admin/products/delete/5
        public async Task<IActionResult> Delete(int id)
        {
            Product product = await context.Products.FindAsync(id);
            if (product == null)
            {
                TempData["Error"] = "The product does not exist";
            }
            else
            {
                if (!string.Equals(product.Image, "noimage.jpg"))
                {
                    string uploadDir = Path.Combine(webHostingEnvironment.WebRootPath, "media/products");
                    string oldImagePath = Path.Combine(uploadDir, product.Image);
                    if (System.IO.File.Exists(oldImagePath))
                    {
                        System.IO.File.Delete(oldImagePath);
                    }
                }

                context.Products.Remove(product);
                await context.SaveChangesAsync();
                TempData["Success"] = "The product has been deleted";
            }
            
            return RedirectToAction("Index");
        }



    }
}
